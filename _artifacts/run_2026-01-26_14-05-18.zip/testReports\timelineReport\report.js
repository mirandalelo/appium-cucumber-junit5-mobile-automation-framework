$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([]);
CucumberHTML.timelineGroups.pushArray([]);
});